#include "dynamique.h"

Dynamique::Dynamique(QObject *parent) :
    QObject(parent)
{

}
