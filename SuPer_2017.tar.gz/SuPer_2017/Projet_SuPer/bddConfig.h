#ifndef BDDCONFIG_H
#define BDDCONFIG_H

#define BDD_HOST_NAME       "localhost"
#define BDD_DATABASE_NAME   "bdd_super2015"
#define BDD_USER_NAME       "super2015"
#define BDD_PASSWORD        "super2015"

#endif // BDDCONFIG_H
